import { Routes, Route } from "react-router-dom";
import Signup from "./pages/Signup";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/Notfound";
import Movies from "./pages/Movies";
import TVShows from "./pages/TVShows";
import Books from "./pages/Books";
import Watchlist from "./pages/watchlist"; // ⬅️ Import Watchlist

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/movies" element={<Movies />} />
      <Route path="/tvshows" element={<TVShows />} />
      <Route path="/books" element={<Books />} />
      <Route path="/watchlist" element={<Watchlist />} /> {/* ⬅️ Add Watchlist route */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
