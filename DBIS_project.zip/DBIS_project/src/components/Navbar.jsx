import React from "react";
import { useNavigate } from "react-router";

const Navbar = ({ onLogout }) => {
  const navigate = useNavigate();

  return (
    <nav style={styles.navbar}>
      <button style={styles.button} onClick={() => navigate("/")}>
        Home
      </button>
      <button style={styles.button} onClick={() => navigate("/movies")}>
        Movies
      </button>
      <button style={styles.button} onClick={() => navigate("/tvshows")}>
        TV Shows
      </button>
      <button style={styles.button} onClick={() => navigate("/books")}>
        Books
      </button>
      <button style={styles.button} onClick={() => navigate("/watchlist")}>
        Watchlist
      </button>
      <button style={styles.logoutButton} onClick={onLogout}>
        Logout
      </button>
    </nav>
  );
};

const styles = {
  navbar: {
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    padding: "10px",
    background: "#333",
    color: "white",
    flexWrap: "wrap",
  },
  button: {
    background: "#555",
    color: "white",
    border: "none",
    padding: "10px 20px",
    margin: "5px",
    cursor: "pointer",
  },
  logoutButton: {
    background: "red",
    color: "white",
    border: "none",
    padding: "10px 20px",
    margin: "5px",
    cursor: "pointer",
  },
};

export default Navbar;
