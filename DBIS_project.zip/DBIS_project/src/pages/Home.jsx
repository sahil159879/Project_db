import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiUrl } from "../config/config";
import Navbar from "../components/Navbar";
import "../css/home.css";

const Home = () => {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const response = await fetch(`${apiUrl}/isLoggedIn`, {
          method: "GET",
          credentials: "include",
        });
        const data = await response.json();

        if (data.loggedIn) {
          setIsLoggedIn(true);
          setUsername(data.username);
        } else {
          setIsLoggedIn(false);
        }
      } catch (error) {
        console.error("Error checking login status:", error);
        setIsLoggedIn(false);
      }
    };

    checkLoginStatus();
  }, []);

  const handleLogout = async () => {
    try {
      const response = await fetch(`${apiUrl}/logout`, {
        method: "POST",
        credentials: "include",
      });

      if (response.ok) {
        setIsLoggedIn(false);
        setUsername("");
        navigate("/");
      } else {
        console.error("Logout failed");
      }
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const dummyMovies = [
    { title: "Inception", image: "/images/inception.jpeg" },
    { title: "Interstellar", image: "/images/interstellar.jpeg" },
    { title: "Tenet", image: "/images/tenet.jpeg" },
    { title: "Oppenheimer", image: "/images/oppenheimer.jpeg" },
    { title: "Rush Hour", image: "/images/rushhour.jpeg" },
  ];

  const dummyTVShows = [
    { title: "Alice in Borderland", image: "/images/aliceinborderland.jpeg" },
    { title: "Stranger Things", image: "/images/strangerthings.jpeg" },
    { title: "Game of Thrones", image: "/images/got.jpeg" },
    { title: "Money Heist", image: "/images/money_heist.jpg" },
    { title: "Boys", image: "/images/boys.jpeg" },
  ];

  const dummyBooks = [
    { title: "Harry Potter", image: "/images/harry_potter.jpeg" },
    { title: "Lord Of Rings", image: "/images/lordofrings.jpg" },
    { title: "Percy Jackson", image: "/images/percy_jackson.jpg" },
    { title: "Hunger Games", image: "/images/hunger_games.jpeg" },
    { title: "The Alchemist", image: "/images/alchemist.jpeg" },
  ];

  const filterItems = (items) =>
    items.filter((item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

  return (
    <div className="home-container">
      {isLoggedIn && (
        <div className="navbar-fixed">
          <Navbar onLogout={handleLogout} />
        </div>
      )}

      <div className="topbar">
        <h2 className="logo">Movie Rating App</h2>
        {isLoggedIn ? (
          <span className="welcome">Welcome, {username}</span>
        ) : (
          <button className="loginButton" onClick={() => navigate("/login")}>
            Login
          </button>
        )}
      </div>

      <div className="search-bar-container">
        <input
          type="text"
          className="search-bar"
          placeholder="Search Movies, TV shows, or Books..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filterItems(dummyMovies).length > 0 && (
        <>
          <h1 className="heading">Explore Movies</h1>
          <div className="grid">
            {filterItems(dummyMovies).map((item, index) => (
              <div key={index} className="card">
                <img src={item.image} alt={item.title} className="image" />
                <p className="title">{item.title}</p>
              </div>
            ))}
          </div>
        </>
      )}

      {filterItems(dummyTVShows).length > 0 && (
        <>
          <h1 className="heading">Explore TV Shows</h1>
          <div className="grid">
            {filterItems(dummyTVShows).map((item, index) => (
              <div key={index} className="card">
                <img src={item.image} alt={item.title} className="image" />
                <p className="title">{item.title}</p>
              </div>
            ))}
          </div>
        </>
      )}

      {filterItems(dummyBooks).length > 0 && (
        <>
          <h1 className="heading">Explore Books</h1>
          <div className="grid">
            {filterItems(dummyBooks).map((item, index) => (
              <div key={index} className="card">
                <img src={item.image} alt={item.title} className="image" />
                <p className="title">{item.title}</p>
              </div>
            ))}
          </div>
        </>
      )}

      {filterItems(dummyMovies).length === 0 &&
        filterItems(dummyTVShows).length === 0 &&
        filterItems(dummyBooks).length === 0 && (
          <p className="no-results">No results found for "{searchQuery}"</p>
      )}
    </div>
  );
};

export default Home;
