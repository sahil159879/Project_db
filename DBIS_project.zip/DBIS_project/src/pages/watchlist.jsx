import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { apiUrl } from "../config/config";
import "../css/home.css"; // Reuse home.css styling

const Watchlist = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(true); // 🔹 Added loading state
  const navigate = useNavigate();

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const response = await fetch(`${apiUrl}/isLoggedIn`, {
          method: "GET",
          credentials: "include",
        });
        const data = await response.json();

        if (data.loggedIn) {
          setIsLoggedIn(true);
          setUsername(data.username);
        } else {
          setIsLoggedIn(false);
        }
      } catch (error) {
        console.error("Error checking login status:", error);
        setIsLoggedIn(false);
      } finally {
        setLoading(false); // 🔹 End loading
      }
    };

    checkLoginStatus();
  }, []);

  const handleLogout = async () => {
    try {
      const response = await fetch(`${apiUrl}/logout`, {
        method: "POST",
        credentials: "include",
      });

      if (response.ok) {
        setIsLoggedIn(false);
        setUsername("");
        navigate("/");
      } else {
        console.error("Logout failed");
      }
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const dummyMovies = [
    { title: "Interstellar", image: "/images/interstellar.jpeg" },
    { title: "Oppenheimer", image: "/images/oppenheimer.jpeg" },
  ];

  const dummyTVShows = [
    { title: "Alice in Borderland", image: "/images/aliceinborderland.jpeg" },
    { title: "Boys", image: "/images/boys.jpeg" },
  ];

  const dummyBooks = [
    { title: "Harry Potter", image: "/images/harry_potter.jpeg" },
    { title: "The Alchemist", image: "/images/alchemist.jpeg" },
  ];

  const filterItems = (items) =>
    items.filter((item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

  if (loading) return null; // 🔹 Wait until login status is known

  return (
    <div className="home-container">
      {isLoggedIn && (
        <div className="navbar-fixed">
          <Navbar onLogout={handleLogout} />
        </div>
      )}

      <div className="topbar">
        <h2 className="logo">Your Watchlist</h2>
        {!isLoggedIn && (
          <button className="loginButton" onClick={() => navigate("/login")}>
            Login
          </button>
        )}
      </div>

      <div className="search-bar-container">
        <input
          type="text"
          className="search-bar"
          placeholder="Search Watchlist..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filterItems(dummyMovies).length > 0 && (
        <>
          <h1 className="heading">Movies</h1>
          <div className="grid">
            {filterItems(dummyMovies).map((item, index) => (
              <div key={index} className="card">
                <img src={item.image} alt={item.title} className="image" />
                <p className="title">{item.title}</p>
              </div>
            ))}
          </div>
        </>
      )}

      {filterItems(dummyTVShows).length > 0 && (
        <>
          <h1 className="heading">TV Shows</h1>
          <div className="grid">
            {filterItems(dummyTVShows).map((item, index) => (
              <div key={index} className="card">
                <img src={item.image} alt={item.title} className="image" />
                <p className="title">{item.title}</p>
              </div>
            ))}
          </div>
        </>
      )}

      {filterItems(dummyBooks).length > 0 && (
        <>
          <h1 className="heading">Books</h1>
          <div className="grid">
            {filterItems(dummyBooks).map((item, index) => (
              <div key={index} className="card">
                <img src={item.image} alt={item.title} className="image" />
                <p className="title">{item.title}</p>
              </div>
            ))}
          </div>
        </>
      )}

      {filterItems(dummyMovies).length === 0 &&
        filterItems(dummyTVShows).length === 0 &&
        filterItems(dummyBooks).length === 0 && (
          <p className="no-results">No results found for "{searchQuery}"</p>
        )}
    </div>
  );
};

export default Watchlist;
